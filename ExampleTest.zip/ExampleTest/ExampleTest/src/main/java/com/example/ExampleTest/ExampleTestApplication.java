package com.example.ExampleTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleTestApplication.class, args);
	}

}
