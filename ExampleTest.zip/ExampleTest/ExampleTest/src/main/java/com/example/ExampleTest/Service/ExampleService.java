/**
 * 
 */
package com.example.ExampleTest.Service;

import com.example.ExampleTest.Request.RequestRating;

/**
 * @author Lenovo
 *
 */
public interface ExampleService {

	String postRating(RequestRating requestRating);

}
