/**
 * 
 */
package com.example.ExampleTest.ServiceImpl;

import org.springframework.stereotype.Service;

import com.example.ExampleTest.Request.RequestRating;
import com.example.ExampleTest.Service.ExampleService;
import com.google.gson.Gson;

/**
 * @author Lenovo
 *
 */
@Service
public class ExampleServiceImpl implements ExampleService{

	Gson gson = new Gson();
	
	@Override
	public String postRating(RequestRating requestRating) {
		return  gson.toJson(requestRating);
	}

}
